import { useState } from "react";
import AppHeader from "@/components/AppHeader";
import ProgressIndicator from "@/components/ProgressIndicator";
import StepsList from "@/components/StepsList";
import NavigationControls from "@/components/NavigationControls";

export default function Home() {
  const [currentStep, setCurrentStep] = useState(1);
  
  const stepTitles = [
    "WiFi 電源",
    "WiFi 設定", 
    "開啟應用程式",
    "載入等待",
    "即時觀看",
    "畫面調整",
    "錄影回放",
    "日期時間選擇"
  ];

  const totalSteps = stepTitles.length;

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      console.log(`Moving to step ${currentStep - 1}`);
    }
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
      console.log(`Moving to step ${currentStep + 1}`);
    }
  };

  const handleHome = () => {
    setCurrentStep(1);
    console.log('Returning to first step');
  };

  const handleStepClick = (stepNumber: number) => {
    setCurrentStep(stepNumber);
    console.log(`Jumping to step ${stepNumber}`);
  };

  const handleMenuClick = () => {
    console.log('Menu clicked - could open sidebar');
  };

  const handleSettingsClick = () => {
    console.log('Settings clicked - could open settings modal');
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader 
        onMenuClick={handleMenuClick}
        onSettingsClick={handleSettingsClick}
      />
      
      <ProgressIndicator
        currentStep={currentStep}
        totalSteps={totalSteps}
        stepTitles={stepTitles}
      />
      
      <main className="px-4 py-6">
        <div className="max-w-2xl mx-auto">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-foreground mb-2">
              監控錄影操作指南
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              按照以下步驟操作，即可成功觀看和尋找 V380 Pro 監控錄影記錄。
              每個步驟都有詳細說明和重要提醒。
            </p>
          </div>
          
          <StepsList 
            currentStep={currentStep}
            onStepClick={handleStepClick}
          />
        </div>
      </main>
      
      <NavigationControls
        currentStep={currentStep}
        totalSteps={totalSteps}
        onPrevious={handlePrevious}
        onNext={handleNext}
        onHome={handleHome}
      />
    </div>
  );
}