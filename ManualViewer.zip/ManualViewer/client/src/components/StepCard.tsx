import { ReactNode } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle } from "lucide-react";

interface StepCardProps {
  stepNumber: number;
  title: string;
  description: string;
  isCompleted?: boolean;
  isActive?: boolean;
  icon?: ReactNode;
  children?: ReactNode;
}

export default function StepCard({ 
  stepNumber, 
  title, 
  description, 
  isCompleted = false, 
  isActive = false,
  icon,
  children 
}: StepCardProps) {
  return (
    <Card className={`
      w-full transition-all duration-200 hover-elevate
      ${isActive ? 'ring-2 ring-primary ring-offset-2' : ''}
      ${isCompleted ? 'bg-muted/30' : ''}
    `}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={`
              flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold
              ${isCompleted 
                ? 'bg-chart-2 text-white' 
                : isActive 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-secondary text-secondary-foreground'
              }
            `}>
              {isCompleted ? (
                <CheckCircle className="w-4 h-4" />
              ) : (
                stepNumber
              )}
            </div>
            
            <div className="flex-1">
              <h3 className={`
                font-semibold text-base leading-tight
                ${isActive ? 'text-primary' : ''}
              `}>
                {title}
              </h3>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {icon}
            {isCompleted && (
              <Badge variant="secondary" className="bg-chart-2/10 text-chart-2 text-xs">
                完成
              </Badge>
            )}
            {isActive && (
              <Badge variant="default" className="text-xs">
                進行中
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <p className="text-sm text-muted-foreground leading-relaxed mb-4">
          {description}
        </p>
        {children}
      </CardContent>
    </Card>
  );
}